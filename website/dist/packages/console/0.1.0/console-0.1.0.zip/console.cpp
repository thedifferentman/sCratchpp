#include "console.hpp"
#include <pte/pte.hpp>
#include <events/events.hpp>
#include <scratch_platform.hpp>
#include <utility>

namespace scratch::console {
namespace {
Options config;
bool initialized = false;
bool repaint = true;
bool flushing = false;
int wheel_handler = 0;
int key_handler = 0;
int oldest = 0;
int newest = 0;
int view = 0;
int column = 0;
unsigned utf_value = 0;
unsigned utf_min = 0;
int utf_remaining = 0;
bool accepting_input = false;
bool turbowarp_input = false;
bool completed_input = false;
std::string input_text;
std::string completed_text;
std::size_t input_limit = 0;
int input_row = 0;
int input_column = 0;

int clamp(int value, int low, int high) {
    return value < low ? low : (value > high ? high : value);
}
int bottom_view() {
    const int candidate = newest - config.rows + 1;
    return candidate < oldest ? oldest : candidate;
}
int index_of(int row, int col) {
    return (row % config.history_lines) * config.columns + col + 1;
}
int read_cell(int row, int col) {
    int result;
    const int index = index_of(row, col);
    asm volatile("data_itemoflist LIST=\"__scl_console::cells\" INDEX=%1"
                 : "=r"(result) : "r"(index) : "memory");
    return result;
}
void set_cell(int row, int col, int cp) {
    const int index = index_of(row, col);
    asm volatile("data_replaceitemoflist LIST=\"__scl_console::cells\" INDEX=%0 ITEM=%1"
                 : : "r"(index), "r"(cp) : "memory");
}
void clear_dirty() {
    asm volatile("data_deletealloflist LIST=\"__scl_console::dirty_rows\";"
                 "data_deletealloflist LIST=\"__scl_console::dirty_cols\";"
                 : : : "memory");
}
void dirty(int row, int col) {
    if (repaint) return;
    asm volatile("data_addtolist LIST=\"__scl_console::dirty_rows\" ITEM=%0;"
                 "data_addtolist LIST=\"__scl_console::dirty_cols\" ITEM=%1;"
                 : : "r"(row), "r"(col) : "memory");
}
void clear_row(int row) {
    const int index = index_of(row, 0);
    asm volatile(
        "data_setvariableto VARIABLE=\"__scl_console_clear_i\" VALUE=%0;"
        "control_repeat TIMES=%1 SUBSTACK %{"
        " data_replaceitemoflist LIST=\"__scl_console::cells\" INDEX=(data_variable VARIABLE=\"__scl_console_clear_i\") ITEM=0;"
        " data_changevariableby VARIABLE=\"__scl_console_clear_i\" VALUE=1; %};"
        : : "r"(index), "r"(config.columns) : "memory");
}
void next_line() {
    const bool follow = view == bottom_view();
    ++newest;
    if (newest - oldest >= config.history_lines) ++oldest;
    clear_row(newest);
    column = 0;
    const int old_view = view;
    if (follow) view = bottom_view();
    else if (view < oldest) view = oldest;
    if (old_view != view) repaint = true;
}
// Match the common terminal width rules without claiming shaping, grapheme
// clustering, or a complete Unicode wcwidth implementation.
int character_width(unsigned cp) {
    return (cp >= 0x1100 && (cp <= 0x115f || cp == 0x2329 || cp == 0x232a ||
            (cp >= 0x2e80 && cp <= 0xa4cf && cp != 0x303f) ||
            (cp >= 0xac00 && cp <= 0xd7a3) || (cp >= 0xf900 && cp <= 0xfaff) ||
            (cp >= 0xfe10 && cp <= 0xfe19) || (cp >= 0xfe30 && cp <= 0xfe6f) ||
            (cp >= 0xff00 && cp <= 0xff60) || (cp >= 0xffe0 && cp <= 0xffe6) ||
            (cp >= 0x1f300 && cp <= 0x1faff) || (cp >= 0x20000 && cp <= 0x3fffd))) ? 2 : 1;
}
void erase_at(int row, int col) {
    const int old = read_cell(row, col);
    if (!old) return;
    repaint = true;
    if (old == -1 && col > 0) set_cell(row, col - 1, 0);
    if (old > 0 && col + 1 < config.columns && read_cell(row, col + 1) == -1)
        set_cell(row, col + 1, 0);
    set_cell(row, col, 0);
}
void put(unsigned cp) {
    if (cp == '\n') { next_line(); return; }
    if (cp == '\r') { column = 0; return; }
    if (cp == '\b') {
        if (column > 0) {
            --column;
            if (read_cell(newest, column) == -1 && column > 0) --column;
            erase_at(newest, column);
        }
        return;
    }
    if (cp == '\t') {
        const int spaces = 8 - (column % 8);
        for (int i = 0; i < spaces; ++i) put(' ');
        return;
    }
    if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) return;
    const int width = character_width(cp);
    if (column + width > config.columns) next_line();
    erase_at(newest, column);
    if (width == 2) erase_at(newest, column + 1);
    set_cell(newest, column, static_cast<int>(cp));
    if (width == 2) set_cell(newest, column + 1, -1);
    dirty(newest, column);
    column += width;
}
void byte(unsigned char value) {
    if (utf_remaining) {
        if ((value & 0xc0) == 0x80) {
            utf_value = (utf_value << 6) | (value & 0x3f);
            if (--utf_remaining == 0) {
                const unsigned cp = utf_value;
                put(cp < utf_min || cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff) ? 0xfffd : cp);
            }
            return;
        }
        utf_remaining = 0;
        put(0xfffd);
        // Reprocess the non-continuation byte as a new sequence.
    }
    if (value < 0x80) put(value);
    else if (value >= 0xc2 && value <= 0xdf) { utf_value = value & 31; utf_min = 0x80; utf_remaining = 1; }
    else if (value >= 0xe0 && value <= 0xef) { utf_value = value & 15; utf_min = 0x800; utf_remaining = 2; }
    else if (value >= 0xf0 && value <= 0xf4) { utf_value = value & 7; utf_min = 0x10000; utf_remaining = 3; }
    else put(0xfffd);
}
void snapshot_position() {
    asm volatile("data_setvariableto VARIABLE=\"__scl_console_saved_x\" VALUE=(motion_xposition);"
                 "data_setvariableto VARIABLE=\"__scl_console_saved_y\" VALUE=(motion_yposition);"
                 : : : "memory");
}
void restore_position() {
    asm volatile("pen_penUp; motion_gotoxy X=(data_variable VARIABLE=\"__scl_console_saved_x\")"
                 " Y=(data_variable VARIABLE=\"__scl_console_saved_y\");" : : : "memory");
}
void timing_refresh() {
    restore_position();
    scratch::events::refresh();
}
void wheel_scroll(int direction, void*) { scroll(direction); }

void key_input(int key, void*) {
    if (!accepting_input) return;
    if ((key >= 32 && key <= 126) || key == 8 || key == 13) {
        if (view != bottom_view()) { view = bottom_view(); repaint = true; }
    }
    if (key == 13) {
        accepting_input = false;
        completed_input = true;
        completed_text = std::move(input_text);
        put('\n');
        return;
    }
    if (key == (turbowarp_input ? 8 : '\\')) {
        if (input_text.empty()) return;
        const int offset = input_column + static_cast<int>(input_text.size()) - 1;
        erase_at(input_row + offset / config.columns, offset % config.columns);
        input_text.pop_back();
        const int end = input_column + static_cast<int>(input_text.size());
        newest = input_row + (end ? (end - 1) / config.columns : 0);
        column = end ? (end - 1) % config.columns + 1 : 0;
        if (view > bottom_view()) view = bottom_view();
        return;
    }
    if (key < 32 || key > 126 || input_text.size() >= input_limit) return;
    input_text.push_back(static_cast<char>(key));
    put(static_cast<unsigned>(key));
}

void draw(int row, int col) {
    if (row < view || row >= view + config.rows || row < oldest || row > newest) return;
    const int cp = read_cell(row, col);
    if (cp <= 0 || cp == ' ') return;
    const int cell_width = (config.font_size + 1) / 2;
    const int x = config.x + col * cell_width;
    const int y = config.y - (row - view) * (config.font_size + 4);
    scratch::pte::draw_cell(static_cast<unsigned>(cp), x, y, config.font_size,
                           cell_width * character_width(static_cast<unsigned>(cp)), config.color);
}
void ensure_init() { if (!initialized) init(); }
} // namespace

void init(const Options& options) {
    config = options;
    config.columns = clamp(config.columns, 2, 120);
    config.rows = clamp(config.rows, 1, 80);
    config.font_size = clamp(config.font_size, 4, 128);
    config.history_lines = clamp(config.history_lines, config.rows, 100000 / config.columns);
    config.color &= 0xffffff;
    initialized = true;
    turbowarp_input = scratch::is_turbowarp();
    oldest = newest = view = column = 0;
    utf_value = utf_min = 0;
    utf_remaining = 0;
    accepting_input = completed_input = false;
    input_text.clear();
    completed_text.clear();
    repaint = true;
    scratch::events::init();
    if (!wheel_handler) wheel_handler = scratch::events::on_wheel(wheel_scroll, nullptr);
    if (!key_handler) key_handler = scratch::events::on_key(key_input, nullptr);
    const int cells = config.history_lines * config.columns;
    asm volatile(
        "data_deletealloflist LIST=\"__scl_console::cells\";"
        "control_repeat TIMES=%0 SUBSTACK %{ data_addtolist LIST=\"__scl_console::cells\" ITEM=0; %};"
        "looks_hide; pen_penUp;"
        : : "r"(cells) : "memory");
    clear_dirty();
}
void write(const char* bytes, std::size_t size) {
    ensure_init();
    if (accepting_input) cancel_input();
    for (std::size_t i = 0; i < size; ++i) byte(static_cast<unsigned char>(bytes[i]));
}
void write(const std::string& text) { write(text.data(), text.size()); }
void write(const char* text) {
    ensure_init();
    if (accepting_input) cancel_input();
    while (*text) byte(static_cast<unsigned char>(*text++));
}
void writeln(const std::string& text) { write(text); byte('\n'); }
void writeln(const char* text) { write(text); byte('\n'); }
void clear() {
    ensure_init();
    oldest = newest = view = column = 0;
    utf_remaining = 0;
    accepting_input = completed_input = false;
    input_text.clear();
    completed_text.clear();
    clear_row(0);
    clear_dirty();
    repaint = true;
}
void scroll(int lines) {
    ensure_init();
    // Clamp before subtraction to avoid overflow for arbitrary public inputs.
    lines = clamp(lines, -config.history_lines, config.history_lines);
    const int next = clamp(view - lines, oldest, bottom_view());
    if (next != view) { view = next; repaint = true; }
}
void flush() {
    ensure_init();
    if (flushing) return;
    flushing = true;
    scratch::events::poll();
    snapshot_position();
    int count;
    if (repaint) {
        asm volatile("pen_clear" : : : "memory");
        const int end = newest < view + config.rows ? newest + 1 : view + config.rows;
        for (int row = view; row < end; ++row)
            for (int col = 0; col < config.columns; ++col) {
                draw(row, col);
                timing_refresh();
            }
    } else {
        asm volatile("data_lengthoflist LIST=\"__scl_console::dirty_rows\"" : "=r"(count) : : "memory");
        for (int i = 1; i <= count; ++i) {
            int row, col;
            asm volatile("data_itemoflist LIST=\"__scl_console::dirty_rows\" INDEX=%1" : "=r"(row) : "r"(i) : "memory");
            asm volatile("data_itemoflist LIST=\"__scl_console::dirty_cols\" INDEX=%1" : "=r"(col) : "r"(i) : "memory");
            draw(row, col);
            timing_refresh();
        }
    }
    repaint = false;
    clear_dirty();
    timing_refresh();
    restore_position();
    flushing = false;
}
double days_since_2000() { return scratch::events::days_since_2000(); }

bool begin_input(const std::string& prompt, std::size_t max_bytes) {
    // Reject callback reentry: after Enter, subsequent keys in this same poll
    // batch must not accidentally feed a newly opened input session.
    if (scratch::events::is_dispatching()) return false;
    ensure_init();
    if (accepting_input || completed_input || !key_handler) return false;
    write(prompt);
    if (utf_remaining) { utf_remaining = 0; put(0xfffd); }
    if (column == config.columns) next_line();
    if (view != bottom_view()) { view = bottom_view(); repaint = true; }
    input_row = newest;
    input_column = column;
    const std::size_t retained_capacity = static_cast<std::size_t>(config.history_lines * config.columns - column);
    input_limit = max_bytes < retained_capacity ? max_bytes : retained_capacity;
    if (input_limit > 4096) input_limit = 4096;
    input_text.clear();
    input_text.reserve(input_limit);
    accepting_input = true;
    return true;
}
bool try_read_line(std::string& text) {
    ensure_init();
    if (!completed_input) return false;
    text = std::move(completed_text);
    completed_input = false;
    return true;
}
std::string read_line(const std::string& prompt, std::size_t max_bytes) {
    if (!begin_input(prompt, max_bytes)) return {};
    while (accepting_input) {
        flush();
        if (accepting_input) scratch::events::yield();
    }
    std::string result;
    try_read_line(result);
    return result;
}
void cancel_input() {
    ensure_init();
    if (!accepting_input) return;
    accepting_input = false;
    input_text.clear();
    // Keep what was already echoed, and give the next output its own line.
    put('\n');
}
bool input_active() { ensure_init(); return accepting_input; }

int line_count() { ensure_init(); return newest - oldest + 1; }
int first_visible_line() { ensure_init(); return view - oldest; }
int cursor_column() { ensure_init(); return column; }
unsigned cell(int history_line, int col) {
    ensure_init();
    if (history_line < 0 || history_line >= line_count() || col < 0 || col >= config.columns) return 0;
    const int value = read_cell(oldest + history_line, col);
    return value > 0 ? static_cast<unsigned>(value) : 0;
}
} // namespace scratch::console
